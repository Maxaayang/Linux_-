package bankqueue;

public enum WindowType {
    kNormal, kFast, kVip, kNumWindows
}
