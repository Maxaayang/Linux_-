#!/bin/sh

g++ -std=c++0x -O2 -Wall -g factorial.cc -o factorial
g++ -std=c++0x -O2 -Wall -g sieve.cc -o sieve
